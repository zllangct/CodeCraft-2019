#!/usr/bin/python
# -*- coding:utf-8 -*-

import simulator.CrossMap as CrossMap


class Global:
    FrameTemp =None
    FrameTime = 0


Global = Global()
