#!/usr/bin/python
# -*- coding:utf-8 -*-

import CrossMap


class Global:
    FrameTemp =None
    FrameTime = 0


Global = Global()
